export const environment = {
  production: true,
  firebase: {
    apiKey: "AIzaSyDG3GmnVS56ArTqSBkiYwMxHsx9FORrBy0",
    authDomain: "oshop-b0b46.firebaseapp.com",
    databaseURL: "https://oshop-b0b46.firebaseio.com",
    projectId: "oshop-b0b46",
    storageBucket: "oshop-b0b46.appspot.com",
    messagingSenderId: "414072848049",
    appId: "1:414072848049:web:80d66466128e9a3e996c90",
    measurementId: "G-G9WTRSVTQ7"
  }
};
