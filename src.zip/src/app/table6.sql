SUM(CASE WHEN campaign_type = 'Hispanic' AND tactic_group = 'Search' AND channel = 'SEM' THEN clicks ELSE NULL END)
SUM(CASE WHEN campaign_type = 'Hispanic' AND tactic_group = 'Search' AND channel = 'SEM' THEN impressions ELSE NULL END)
SUM(CASE WHEN campaign_type = 'Hispanic' AND tactic_group = 'Search' AND channel = 'SEM' THEN spend ELSE NULL END)
SUM(CASE WHEN campaign_type = 'Hispanic' AND fm_nonfm = 'FM' AND tactic_group = 'Search' AND channel = 'SEM' THEN clicks ELSE NULL END)
SUM(CASE WHEN campaign_type = 'Hispanic' AND fm_nonfm = 'FM' AND tactic_group = 'Search' AND channel = 'SEM' THEN impressions ELSE NULL END)
SUM(CASE WHEN campaign_type = 'Hispanic' AND fm_nonfm = 'FM' AND tactic_group = 'Search' AND channel = 'SEM' THEN spend ELSE NULL END)
SUM(CASE WHEN campaign_type = 'Hispanic' AND fm_nonfm = 'NON-FM' AND tactic_group = 'Search' AND channel = 'SEM' THEN clicks ELSE NULL END)
SUM(CASE WHEN campaign_type = 'Hispanic' AND fm_nonfm = 'NON-FM' AND tactic_group = 'Search' AND channel = 'SEM' THEN impressions ELSE NULL END)
SUM(CASE WHEN campaign_type = 'Hispanic' AND fm_nonfm = 'NON-FM' AND tactic_group = 'Search' AND channel = 'SEM' THEN spend ELSE NULL END)




HISPANIC_CLICKS_DMA_SEM_SEARCH
HISPANIC_IMPRESSIONS_DMA_SEM_SEARCH
HISPANIC_SPEND_DMA_SEM_SEARCH
HISPANIC_CLICKS_FM_DMA_SEM_SEARCH
HISPANIC_IMPRESSIONS_FM_DMA_SEM_SEARCH
HISPANIC_SPEND_FM_DMA_SEM_SEARCH
HISPANIC_CLICKS_NON_FM_DMA_SEM_SEARCH
HISPANIC_IMPRESSIONS_NON_FM_DMA_SEM_SEARCH
HISPANIC_SPEND_NON_FM_DMA_SEM_SEARCH