       SUM(CASE WHEN campaign_type = 'Hispanic' AND tactic_group = 'Search' AND channel = 'SEM' THEN clicks ELSE NULL END) ,
       SUM(CASE WHEN campaign_type = 'Hispanic' AND tactic_group = 'Search' AND channel = 'SEM' THEN impressions ELSE NULL END) ,
	   SUM(CASE WHEN campaign_type = 'Hispanic' AND tactic_group = 'Search' AND channel = 'SEM' THEN spend ELSE NULL END) ,
	   SUM(CASE WHEN campaign_type = 'Hispanic' AND tactic_group = 'Search' AND channel = 'SEM' AND fm_nonfm = 'FM' THEN clicks ELSE NULL END) ,
	   SUM(CASE WHEN campaign_type = 'Hispanic' AND tactic_group = 'Search' AND channel = 'SEM' AND fm_nonfm = 'FM' THEN impressions ELSE NULL END) ,
	   SUM(CASE WHEN campaign_type = 'Hispanic' AND tactic_group = 'Search' AND channel = 'SEM' AND fm_nonfm = 'FM' THEN spend ELSE NULL END),
	   SUM(CASE WHEN campaign_type = 'Hispanic' AND tactic_group = 'Search' AND channel = 'SEM' AND fm_nonfm = 'NON-FM' THEN clicks ELSE NULL END) ,
	   SUM(CASE WHEN campaign_type = 'Hispanic' AND tactic_group = 'Search' AND channel = 'SEM' AND fm_nonfm = 'NON-FM' THEN impressions ELSE NULL END) ,
	   SUM(CASE WHEN campaign_type = 'Hispanic' AND tactic_group = 'Search' AND channel = 'SEM' AND fm_nonfm = 'NON-FM' THEN spend ELSE NULL END)