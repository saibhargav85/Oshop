import { Component, OnInit } from '@angular/core';
import { AuthService } from '../Services/auth.service';
import { AppUser } from 'src/models/app-user';
import { ShoppingCartService } from '../Services/shopping-cart.service';
import { Observable } from 'rxjs';
import { ShoppingCart } from 'src/models/shopping-cart';


@Component({
  selector: 'bs-navbar',
  templateUrl: './bs-navbar.component.html',
  styleUrls: ['./bs-navbar.component.css']
})
export class BsNavbarComponent implements OnInit{
  appUser:AppUser;
  cart$:Observable<ShoppingCart>;
  cart
   
  constructor(public authService:AuthService, private cartService:ShoppingCartService) { 
  }

  async ngOnInit()
  {
    this.authService.user$.subscribe(appUser => this.appUser=appUser)
    let cart$= (await this.cartService.getCart()).subscribe(x => this.cart=x)
  }

  logout()
  {
    this.authService.logout();
  }
}
