import { Injectable } from '@angular/core';
import { CanActivate } from '@angular/router';
import { AuthService } from './auth.service';
import { map,switchMap } from 'rxjs/operators'
import { UserService } from './user.service';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AdminAuthGuard implements CanActivate {

  constructor(private Auth:AuthService, private userService:UserService) { }

  canActivate():Observable<boolean>
  {
     return this.Auth.user$
     .pipe(switchMap(user => { 
       let c= this.userService.get(user.uid).valueChanges()
       return c
      }))
      .pipe(map(appUser => {
       return appUser.isAdmin        
      }))
  }
}
