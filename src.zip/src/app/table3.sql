SUM(CASE WHEN campaign_type = 'General' AND objective_group = 'Active Shopper - MID' AND tactic_group = 'Other' AND medium = 'Audio' AND fm_nonfm = 'FM' AND d.dma_code NOT IN(1,9999) THEN impressions ELSE 0 END) metric43,
SUM(CASE WHEN campaign_type = 'General' AND objective_group = 'Active Shopper - MID' AND tactic_group = 'Other' AND medium = 'Audio' AND fm_nonfm = 'FM' AND d.dma_code NOT IN(1,9999) THEN spend ELSE 0 END) metric44,
SUM(CASE WHEN campaign_type = 'General' AND objective_group = 'Active Shopper - MID' AND tactic_group = 'Other' AND medium = 'Audio' AND fm_nonfm = 'NON-FM' AND d.dma_code NOT IN(1,9999) THEN clicks ELSE 0 END) metric45,
SUM(CASE WHEN campaign_type = 'General' AND objective_group = 'Active Shopper - MID' AND tactic_group = 'Other' AND medium = 'Audio' AND fm_nonfm = 'NON-FM' AND d.dma_code NOT IN(1,9999) THEN impressions ELSE 0 END) metric46,
SUM(CASE WHEN campaign_type = 'General' AND objective_group = 'Active Shopper - MID' AND tactic_group = 'Other' AND medium = 'Video' AND fm_nonfm = 'FM' AND d.dma_code NOT IN(1,9999) THEN clicks ELSE 0 END) metric47,
SUM(CASE WHEN campaign_type = 'General' AND objective_group = 'Active Shopper - MID' AND tactic_group = 'Other' AND medium = 'Video' AND fm_nonfm = 'FM' AND d.dma_code NOT IN(1,9999) THEN impressions ELSE 0 END) metric48,
SUM(CASE WHEN campaign_type = 'General' AND objective_group = 'Active Shopper - MID' AND tactic_group = 'Other' AND medium = 'Video' AND fm_nonfm = 'FM' AND d.dma_code NOT IN(1,9999) THEN spend ELSE 0 END) metric49,
SUM(CASE WHEN campaign_type = 'General' AND objective_group = 'Active Shopper - MID' AND tactic_group = 'Other' AND medium = 'Video' AND fm_nonfm = 'NON-FM' AND d.dma_code NOT IN(1,9999) THEN clicks ELSE 0 END) metric50






	PAIDDISPLAY_GENERAL_ACTIVE SHOPPER - MID_OTHER_AUDIO_FM_DMA_IMPRESSIONS
	PAIDDISPLAY_GENERAL_ACTIVE SHOPPER - MID_OTHER_AUDIO_FM_DMA_SPEND
	PAIDDISPLAY_GENERAL_ACTIVE SHOPPER - MID_OTHER_AUDIO_NON-FM_DMA_CLICKS
	PAIDDISPLAY_GENERAL_ACTIVE SHOPPER - MID_OTHER_AUDIO_NON-FM_DMA_IMPRESSIONS
	PAIDDISPLAY_GENERAL_ACTIVE SHOPPER - MID_OTHER_VIDEO_FM_DMA_CLICKS
	PAIDDISPLAY_GENERAL_ACTIVE SHOPPER - MID_OTHER_VIDEO_FM_DMA_IMPRESSIONS
	PAIDDISPLAY_GENERAL_ACTIVE SHOPPER - MID_OTHER_VIDEO_FM_DMA_SPEND
	PAIDDISPLAY_GENERAL_ACTIVE SHOPPER - MID_OTHER_VIDEO_NON-FM_DMA_CLICKS





