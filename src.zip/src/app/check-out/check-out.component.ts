import { Component, OnInit } from '@angular/core';
import { shipping } from 'src/models/shipping';
@Component({
  selector: 'app-check-out',
  templateUrl: './check-out.component.html',
  styleUrls: ['./check-out.component.css']
})
export class CheckOutComponent implements OnInit {
  shipping:shipping = {}; 
  constructor() { }

  ngOnInit() {
  } 
  
  placeOrder() {
    console.log(this.shipping);
  }  

}
