import { Component, OnInit } from '@angular/core';
import { CategoryService } from 'src/app/Services/category.service';
import { ProductService } from 'src/app/Services/product.service';
import { Router, ActivatedRoute } from '@angular/router';
import {take} from 'rxjs/operators'
import {Product} from 'src/models/Product'

@Component({
  selector: 'app-product-form',
  templateUrl: './product-form.component.html',
  styleUrls: ['./product-form.component.css']
})
export class ProductFormComponent implements OnInit {
categories$;
id;
product=<Product>{};

  constructor(categoryService:CategoryService,private productService:ProductService ,private router:Router, private route:ActivatedRoute) {
    this.categories$=categoryService.getCategories().valueChanges()
    this.id=this.route.snapshot.paramMap.get('id');

    if(this.id) this.productService.get(this.id).valueChanges().pipe(take(1)).subscribe(p => {this.product=p; })
   }

  ngOnInit(): void {
  }

  save(product)
  {
    if(this.id) {
      this.productService.update(this.id, product);
    }
    else {this.productService.create(product);}

    this.router.navigate(['/admin/products']);
  }

  getAll()
  {
    this.productService.getAll()
  }
}
