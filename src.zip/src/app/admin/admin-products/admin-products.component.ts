import { Component, OnInit, OnDestroy } from '@angular/core';
import { ProductService } from 'src/app/Services/product.service';
import { Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { Product } from 'src/models/product';
import { map } from 'rxjs/operators'

@Component({
  selector: 'app-admin-products',
  templateUrl: './admin-products.component.html',
  styleUrls: ['./admin-products.component.css']
})
export class AdminProductsComponent implements OnInit, OnDestroy {
products$
products:Product[];
filteredProducts:any[];
subscription:Subscription
  constructor(private productService:ProductService,private router:Router) { 
    //this.products$=this.productService.getAll().valueChanges()
    this.subscription=this.productService.getAll().snapshotChanges().pipe(map(actions =>{
      return actions.map(p => {
        const key=p.payload.key;
        const data=p.payload.val();
        data["key"]=key;
        return data;
      })
    }))
    .subscribe(products => this.filteredProducts=this.products=products)
  }

  ngOnInit() {
  }

  filter(query:string)
  {
     this.filteredProducts=(query)?
      this.products.filter(p => p.title.toLowerCase().includes(query.toLowerCase())) : this.products;
  }

  ngOnDestroy()
  {
    this.subscription.unsubscribe();
  }


  delete(id)
  {
    if(!confirm('Are you sure you want to delete this product')) return;

    this.productService.delete(id)
    this.router.navigate(['/admin/products']);
  }

}
