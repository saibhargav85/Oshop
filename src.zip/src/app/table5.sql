SELECT wk_start_date, wk_end_date, CAST(d.dma_code AS VARCHAR(30)), d.dma_name,
SUM(CASE WHEN campaign_type = 'General' AND objective_group = 'Active Shopper - LOW' AND tactic_group = 'Content Amplification' AND medium_group = 'Audio' AND sitename = 'inPowered' AND fm_nonfm = 'FM' AND d.dma_code NOT IN(1,9999) THEN spend ELSE 0 END) metric1,
SUM(CASE WHEN campaign_type = 'Hispanic' AND objective_group = 'Brand' AND tactic_group = 'Content Amplification' AND medium_group = 'Audio' AND sitename = 'inPowered' AND fm_nonfm = 'NON-FM' AND d.dma_code NOT IN(1,9999) THEN clicks ELSE 0 END) metric2,
SUM(CASE WHEN campaign_type = 'Hispanic' AND objective_group = 'Brand' AND tactic_group = 'Content Amplification' AND medium_group = 'Content' AND sitename = 'Nativo' AND fm_nonfm = 'FM' AND d.dma_code NOT IN(1,9999) THEN impressions ELSE 0 END) metric3,
SUM(CASE WHEN campaign_type = 'Hispanic' AND objective_group = 'Active Shopper - LOW' AND tactic_group = 'Content Amplification' AND medium_group = 'Audio' AND sitename = 'Nativo' AND fm_nonfm = 'NON-FM' AND d.dma_code IN(1,9999) THEN clicks ELSE 0 END) metric4,
SUM(CASE WHEN campaign_type = 'Hispanic' AND objective_group = 'Brand' AND tactic_group = 'Content Amplification' AND medium_group = 'Audio' AND sitename = 'Nativo' AND fm_nonfm = 'FM' AND d.dma_code  IN(1,9999) THEN impressions ELSE 0 END) metric5
FROM 
mnaoprod.ds013_01_paid_display_prod p
INNER JOIN datamart.mnaoprod.dim_calendar c ON p.calendar_date = c.calendar_date AND p.calendar_dateid = c.calendar_dateid AND calendar_type = 'Sales'
INNER JOIN datamart.mnaoprod.dim_dma d ON d.dma_code = p.dma_code AND p.dma_name = d.dma_name
WHERE d.fm_ind = 1 AND wk_start_date >= '2017-04-03' AND wk_start_date <= '2020-06-22' AND source_vendor <> 'YouTube'
GROUP BY wk_start_date, wk_end_date, d.dma_code, d.dma_name










	PAIDDISPLAY_GENERAL_ACTIVE SHOPPER - LOW_CONTENT AMPLIFICATION_INPOWERED_AUDIO_FM_DMA_SPEND
	PAIDDISPLAY_HISPANIC_BRAND_CONTENT AMPLIFICATION_INPOWERED_AUDIO_NON-FM_DMA_CLICKS
	PAIDDISPLAY_HISPANIC_BRAND_CONTENT AMPLIFICATION_NATIVO_CONTENT_FM_DMA_IMPRESSIONS
	PAIDDISPLAY_HISPANIC_ACTIVE SHOPPER - LOW_CONTENT AMPLIFICATION_NATIVO_AUDIO_NON-FM_NATIONAL+UNKNOWN_CLICKS
	PAIDDISPLAY_HISPANIC_BRAND_CONTENT AMPLIFICATION_NATIVO_AUDIO_FM_NATIONAL+UNKNOWN_IMPRESSIONS
