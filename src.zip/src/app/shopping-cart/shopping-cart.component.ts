import { Component, OnInit, OnDestroy } from '@angular/core';
import { ShoppingCartService } from '../Services/shopping-cart.service';
import { Subscription } from 'rxjs';
import { ShoppingCart } from 'src/models/shopping-cart';
import { Product } from 'src/models/product';

@Component({
  selector: 'app-shopping-cart',
  templateUrl: './shopping-cart.component.html',
  styleUrls: ['./shopping-cart.component.css']
})
export class ShoppingCartComponent implements OnInit,OnDestroy {
  cart:ShoppingCart;
  items;
  totalPrice;
  subscription:Subscription
  constructor(private cartService:ShoppingCartService) {
   }

  async ngOnInit() {
    this.subscription=(await this.cartService.getCart()).subscribe(cart =>  {
      this.cart=new ShoppingCart(cart.items);
      this.totalPrice=cart.totalPrice()
    })   
  }

  ngOnDestroy()
  {
    this.subscription.unsubscribe();
  }
  clearCart()
  {
    this.cartService.clearCart();
  }
}
