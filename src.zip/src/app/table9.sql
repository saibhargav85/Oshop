SUM(CASE WHEN campaign_type = 'General' AND objective_group = 'Active Shopper - LOW' AND tactic_group = 'Behavioral Targeting' AND medium_group = 'Audio' AND fm_nonfm = 'NON-FM' AND d.dma_code NOT IN(1,9999) THEN impressions ELSE 0 END) metric1,
SUM(CASE WHEN campaign_type = 'General' AND objective_group = 'Active Shopper - LOW' AND tactic_group = 'Behavioral Targeting' AND medium = 'Display' AND fm_nonfm = 'FM' AND d.dma_code NOT IN(1,9999) THEN clicks ELSE 0 END) metric2,
SUM(CASE WHEN campaign_type = 'General' AND objective_group = 'Active Shopper - LOW' AND tactic_group = 'Content Amplification' AND medium = 'Display' AND fm_nonfm = 'NON-FM' AND d.dma_code NOT IN(1,9999) THEN clicks ELSE 0 END) metric3,
SUM(CASE WHEN campaign_type = 'General' AND objective_group = 'Active Shopper - LOW' AND tactic_group = 'Contextual Targeting' AND medium = 'Video' AND fm_nonfm = 'FM' AND d.dma_code NOT IN(1,9999) THEN clicks ELSE 0 END) metric4,
SUM(CASE WHEN campaign_type = 'General' AND objective_group = 'Active Shopper - LOW' AND tactic_group = 'Sponsorship' AND medium = 'Audio' AND fm_nonfm = 'NON-FM' AND d.dma_code NOT IN(1,9999) THEN impressions ELSE 0 END) metric5,
SUM(CASE WHEN campaign_type = 'General' AND objective_group = 'Active Shopper - LOW' AND tactic_group = 'Sponsorship' AND medium = 'Audio' AND fm_nonfm = 'NON-FM' AND d.dma_code NOT IN(1,9999) THEN spend ELSE 0 END) metric6,
SUM(CASE WHEN campaign_type = 'General' AND objective_group = 'Active Shopper - LOW' AND tactic_group = 'Sponsorship' AND medium = 'Video' AND fm_nonfm = 'FM' AND d.dma_code NOT IN(1,9999) THEN clicks ELSE 0 END) metric7,
SUM(CASE WHEN campaign_type = 'General' AND objective_group = 'Active Shopper - LOW' AND tactic_group = 'Sponsorship' AND medium = 'Video' AND fm_nonfm = 'FM' AND d.dma_code NOT IN(1,9999) THEN impressions ELSE 0 END) metric8,
SUM(CASE WHEN campaign_type = 'General' AND objective_group = 'Active Shopper - LOW' AND tactic_group = 'Sponsorship' AND medium = 'Video' AND fm_nonfm = 'FM' AND d.dma_code NOT IN(1,9999) THEN spend ELSE 0 END) metric9,
SUM(CASE WHEN campaign_type = 'General' AND objective_group = 'Active Shopper - MID' AND tactic_group = 'Behavioral Targeting' AND medium = 'Content' AND fm_nonfm = 'NON-FM' AND d.dma_code NOT IN(1,9999) THEN spend ELSE 0 END) metric10,
SUM(CASE WHEN campaign_type = 'General' AND objective_group = 'Active Shopper - MID' AND tactic_group = 'Behavioral Targeting' AND medium = 'Display' AND fm_nonfm = 'FM' AND d.dma_code NOT IN(1,9999) THEN clicks ELSE 0 END) metric11,
SUM(CASE WHEN campaign_type = 'General' AND objective_group = 'Active Shopper - MID' AND tactic_group = 'Behavioral Targeting' AND medium = 'Display' AND fm_nonfm = 'FM' AND d.dma_code NOT IN(1,9999) THEN impressions ELSE 0 END) metric12,
SUM(CASE WHEN campaign_type = 'General' AND objective_group = 'Active Shopper - MID' AND tactic_group = 'Behavioral Targeting' AND medium = 'Display' AND fm_nonfm = 'FM' AND d.dma_code NOT IN(1,9999) THEN spend ELSE 0 END) metric13,
SUM(CASE WHEN campaign_type = 'General' AND objective_group = 'Active Shopper - MID' AND tactic_group = 'Content Amplification' AND medium = 'Display' AND fm_nonfm = 'FM' AND d.dma_code NOT IN(1,9999) THEN clicks ELSE 0 END) metric14,
SUM(CASE WHEN campaign_type = 'General' AND objective_group = 'Active Shopper - MID' AND tactic_group = 'Content Amplification' AND medium = 'Display' AND fm_nonfm = 'FM' AND d.dma_code NOT IN(1,9999) THEN impressions ELSE 0 END) metric15,
SUM(CASE WHEN campaign_type = 'General' AND objective_group = 'Active Shopper - MID' AND tactic_group = 'Content Amplification' AND medium = 'Display' AND fm_nonfm = 'FM' AND d.dma_code NOT IN(1,9999) THEN spend ELSE 0 END) metric16,
SUM(CASE WHEN campaign_type = 'General' AND objective_group = 'Active Shopper - MID' AND tactic_group = 'Demo Targeting' AND medium = 'Video' AND fm_nonfm = 'NON_FM' AND d.dma_code NOT IN(1,9999) THEN clicks ELSE 0 END) metric17,
SUM(CASE WHEN campaign_type = 'General' AND objective_group = 'Active Shopper - MID' AND tactic_group = 'Demo Targeting' AND medium = 'Video' AND fm_nonfm = 'NON_FM' AND d.dma_code NOT IN(1,9999) THEN impressions ELSE 0 END) metric18,
SUM(CASE WHEN campaign_type = 'General' AND objective_group = 'Active Shopper - MID' AND tactic_group = 'Demo Targeting' AND medium = 'Video' AND fm_nonfm = 'NON_FM' AND d.dma_code NOT IN(1,9999) THEN spend ELSE 0 END) metric19,
SUM(CASE WHEN campaign_type = 'General' AND objective_group = 'Active Shopper - MID' AND tactic_group = 'Other' AND medium = 'Audio' AND fm_nonfm = 'FM' AND d.dma_code NOT IN(1,9999) THEN spend ELSE 0 END) metric20,
SUM(CASE WHEN campaign_type = 'General' AND objective_group = 'Active Shopper - MID' AND tactic_group = 'Other' AND medium = 'Audio' AND fm_nonfm = 'NON-FM' AND d.dma_code NOT IN(1,9999) THEN clicks ELSE 0 END) metric21,
SUM(CASE WHEN campaign_type = 'General' AND objective_group = 'Active Shopper - MID' AND tactic_group = 'Other' AND medium = 'Audio' AND fm_nonfm = 'NON-FM' AND d.dma_code NOT IN(1,9999) THEN impressions ELSE 0 END) metric22,
SUM(CASE WHEN campaign_type = 'General' AND objective_group = 'Active Shopper - MID' AND tactic_group = 'Other' AND medium = 'Video' AND fm_nonfm = 'FM' AND d.dma_code NOT IN(1,9999) THEN clicks ELSE 0 END) metric23,
SUM(CASE WHEN campaign_type = 'General' AND objective_group = 'Active Shopper - MID' AND tactic_group = 'Other' AND medium = 'Video' AND fm_nonfm = 'FM' AND d.dma_code NOT IN(1,9999) THEN impressions ELSE 0 END) metric24,
SUM(CASE WHEN campaign_type = 'General' AND objective_group = 'Active Shopper - MID' AND tactic_group = 'Other' AND medium = 'Video' AND fm_nonfm = 'NON-FM' AND d.dma_code NOT IN(1,9999) THEN clicks ELSE 0 END) metric25









