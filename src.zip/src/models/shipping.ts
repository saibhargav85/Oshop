export interface shipping{
    name?:string,
    addressline1?:string,
    addressline2?:string,
    city?:string
}